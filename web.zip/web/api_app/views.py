from django.shortcuts import render

# Create your views here.
from django.http import HttpResponse
import pymysql
import os
from api_app.get_data import Mysql
from rest_framework.response import Response
from rest_framework.views import APIView


class ResponseView(APIView):
    def get(self, request, *args, **kwargs):
        ob = Mysql()
        row = ob.getData()
        data = dict(map(reversed, row))
        return Response(data)


def apiLink(request):
    gotoAbout = "<a href='/api/book-lists'> tap to see book lists <a/>"
    return HttpResponse(gotoAbout)
