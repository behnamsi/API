import pymysql
import os


# getting data from database
class Mysql:
    def getData(self):
        myDB = pymysql.connect(
            host='localhost',
            user=os.environ.get('DB_user'),
            passwd=os.environ.get('DB_passwd'),
            database='library_management'
        )
        myCursor = myDB.cursor()
        myCursor.execute('select title,author from Books')
        myTuple = myCursor.fetchall()
        myDB.commit()
        return myTuple
